# ng-ui-components-library

## Installation

### Prerequisites

- [`Node.js`](https://nodejs.org/en/download/) > v16.10.0
- `npm` > v7
- `create-react-app` (latest would be good)

### Project Setup

Install dependencies

```
$ npm i
```

After installing dependencies, install node-sass package to use Scss.

```
$ npm i node-sass
```

## Test & Code Coverage

To Test the project:

```
$ npm run test
```

To check the code coverage

```
$ npm run coverage
```

## To configure husky please follow below commands

```
$ npx husky-init
```

```
$ npx husky set .husky/pre-commit "npx pretty-quick --staged"
```

With the help of the above command it automatically format your below files with prettier ( node module )

```
js,jsx,html,css,less,ejs
```

Host the components in storybook:

```
$ npm start
```

This command will host the storybook and you can see all the component in storybook. Use the storybook canvas for component demo and rendering purpose.

## Usage

### Component Installation

Install from the command line:

## Contributing

### New component

New components should be added with following folder structure:

```
-- src/
   |-- {component-name}/
       |-- {component-name}.tsx
   |-- index.ts
```

The `index.ts` is used to export all the components created under `src`. Logical folder structure for grouping components under `src` folder is welcomed. But while exporting components from `index.ts`, it is not needed.

### General Contribution Guide

- Unit Tests are mandatory to add a component in library or to add new feature in existing component.
- For bug fixes, if required, modify the tests.
- The `git tag` is used for maintaining versions. [Semantic versioning](https://semver.org/) is followed where version number is incremented with help of **major**, **minor** and **patch** terms.

Contributions are what make product complete, meaningful and perfect. Any contributions you make are _greatly appreciated_.

1. Create your Feature Branch (`git checkout -b feature/{git-user-name}/{feature-name}`)

2. Export the components from index.ts file so that it will also reflect in the main package. That way components can be referenced/used in applications.

3. Commit your Changes (`git commit -m 'Add some amazing-feature'`)

4. Push to the Branch (`git push origin feature/{my-name}/amazing-feature`)

5. Open a Pull Request after rebasing feature branch with default branch (`master`).

Once code is merged into master, publish the components into library with appropriate version by using following commands. Github token with appropriate role is required to publish the version.

```
git checkout master
git pull --rebase
npm version {major.minor.patch}
npm publish
```

## Description for created Components.

### Component Name - Button Component

Buttons allow users to take actions, and make choices, with a single tap.

- In Button component We have passed **props** for button like

```
disabled?: boolean;
children?: ReactNode;
onClick?: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
style?: styleObj;
size?: "xs" | "sm" | "md" | "lg" | "xl" | "xxl";
color?: "primary" | "default" | "success" | "error" | "info" | "warning";
round?: "round" | "pill" | "flat";
variant?: "contained" | "outline" | "soft" | "text";
className?: string;
block?: boolean;
raised?: boolean;
isLoader?: boolean;
```

### Example

```
<Button size="xl" variant="soft" round="round" >
```

### Component name- ButtonGroup Component

The ButtonGroup component can be used to group related buttons.

- In ButtonGroup component we have passed **props** like

```
round?: "flat" | "round" | "pill";
className?: string;
children?: ReactNode;
```

### Example

```
<ButtonGroup round='flat'>
<Button children='One'  round='flat' variant="contained" color='info' size='lg' />
<Button children='Two'  round='flat' variant="contained" color='info' size='md' />
<ButtonGroup/>
```

### Component name- CheckBox Component

Checkboxes allow the user to select one or more items from a set and also can be used to turn an option on or off.

- In Checkbox component we have passed **props** like ,

```
color?: "primary" | "default" | "success" | "error" | "info" | "warning";
value?: string;
size?: "sm" | "md" | "lg";
position?: "top" | "left" | "right" | "bottom";
checked?: boolean;
disabled?: boolean;
onChange?: (e) => void;
indeterminate?: boolean;
defaultChecked?: boolean;
circle?: boolean;
```

### Example

```
<Checkbox color="info" size="md" value="python" position="right" />
```

### Component Name - Radio Component

The Radio Group allows the user to select one option from a set.

- In Radio component we have passed **props** like

```
style?: any;
onCloseClick?: () => void;
bgColor?: "primary" | "default" | "success" | "error" | "info" | "warning";
size?: "xs" | "sm" | "md" | "lg" | "xl" | "xxl";
position?: "top" | "left" | "right" | "bottom";
value?: string;
disable?: boolean;
required?: boolean;
className?: string;
height?: string;
```

### Example

```
<Radio bgColor="info" size="xl" value="python" position="right" />
```

### Component Name - Animate Button Component

When pressed, a floating action button can display three to six related actions in the form of a Speed Dial.

- In Animate component We have passed **props** for button like ,

```
size: "xs" | "sm" | "md" | "lg" | "xl" | "xxl";
color: "primary" | "default" | "success" | "error" | "info" | "warning";
round: "round" | "pill" | "flat";
raised: boolean;
buttonProps: ButtonProps;
className?: string;
children?: ReactNode;
animate?: boolean;
onClick?: () => void;
toggle?: boolean;
text?: string;
```

### Example

```
<AnimateButton
animate={false}
onClick={handleClick}
toggle={toggle}
text="Add"
/>
```

### Component Name - Typograpgy

The Typography component makes it easy to apply a default set of font weights and sizes in your application.

- In Typography component We have passed **props** for button like ,

```
typoVariant?:
| "h1"
| "h2"
| "h3"
| "h4"
| "h5"
| "h6"
| "subheading1"
| "body1"
| "button"
| "";
typoColor?: "primary" | "error" | "";
children?: React.ReactNode;
typoStyle?: CustomStyle;
```

### Example

```
<Typography typoVariant="h1" typoColor="" children="h1. heading" />
```

### Component Name - More Menu Compnent

A menu displays a list of choices on a temporary surface. It appears when the user interacts with a button, or other control.

- In Menu component We have passed **props** like ,

```
list: ListObjectType[];
slideFrom?: "right-top" | "left-top";
className?: string;
itemClass?: string;
menuClass?: string;
style?: CustomStyle;
```

### Example

```
<MoreMenu
list={list}
/>
```

### component Name - SnackBar Component

The SnackBar component is used to show messages like success alerts, error messages, or general information.

- In SnackBar component We have passed **props** like ,

```
btnProps {
title: string;
handleClick: () => void;
}
onCloseClick: ()=> void;
round?: "round" | "pill" | "flat";
message?: string;
isVisible: boolean;
bgColor?: "primary" | "default" | "success" | "error" | "info" | "warning";
leftIcon?: ReactNode;
hasActionBtn?: btnProps;
height?:string;
autoHide?: boolean;
animationTime?: number;
duration?: number;
position?: "top" | "top-right" | "top-left" | "bottom" | "bottom-left" | "bottom-right";
```

### Example

```
<Snackbar
message="This is warning message"
bgColor="success"
onCloseClick={handleClose}
isVisible={showToast}
height="30px"
position="top"
hasActionBtn= {}
/>
```

### Component Name - Tag Component

Tags allow users to enter information, make selections, filter content, or trigger actions.

- we have passed **props** like,

```
avatar?: JSX.Element;
icon?: JSX.Element;
tagText?: string;
color?: "primary" | "default" | "success" | "error" | "info" | "warning";
size?: "sm" | "md";
round?: "flat" | "round" | "pill";
className?: string;
variant?: "filled" | "outline";
label?: string;
children?: ReactNode;
allowDelete?: boolean;
onDelete?: () => void;
```

### Example

```
<Tags
icon=''
label="label"
tagText="Avatar"
size="sm"
onDelete={}
> </Tags>
```

### Component Name - TimeLine Component

Timelines are used in user interfaces to create a step-by-step procedure. It can describe to the user which stage of the process they currently are and what the further tasks are.

In TimeLine Component TimelineItem,TimelineSeparator,TimelineDot,TimelineConnector,TimelineContent are the children component.

- We have passed **props** in Timeline Component like ,

```
children?: ReactNode;
className?: string;
classes?: object;
position?: 'left' | 'right' | 'alternate';
style?: CustomStyle;
```

- We have passed **props** in TimelineItem like,

```
classes?: object;
children?: ReactNode;
className?: string;
style?: CustomStyle;
```

- We have passed **props** in TimelineSeparator like,

```
classes?: object;
children?: ReactNode;
className?: string;
style?: CustomStyle;
```

- We have passed **props** in TimelineDot like,

```
children?: ReactNode;
className?: string;
classes?: object;
variant?: 'filled' | 'outline' | string;
style?: CustomStyle;
color?: 'error' | 'info' | 'primary' | 'default' | 'success' | 'warning' | string;
```

- We have passed **props** in TimelineConnector like,

```
children?: ReactNode;
className?: string;
classes?: object;
style?: CustomStyle;
```

- We have passed **props** in TimelineContent like,

```
children?: ReactNode;
className?: string;
classes?: object;
style?: CustomStyle;
```

### Example

```
<Timeline>
<TimelineItem >
<TimelineSeparator>
<TimelineDot ></TimelineDot>
<TimelineConnector />
</TimelineSeparator>
<TimelineContent ></TimelineContent>
</TimelineItem>
</Timeline>
```

### Component Name - Loader Component , LinerProgress Bar , CircularProgress Bar

The Loader component is a visual indicator that expresses an indeterminate wait time.

- We have passed **props** in loader component like ,

```
width?: string;
variants?: string;
```

### Example

```
<Loader width="7rem" variants="secondary" />
```

The linear progress bar is often used to show download and upload percentages in the application.

- We have passed **props** in LinerProgress Bar component like ,

```
value?: number;
style?: any;
```

### Example

```
<LinearProgressBar
value={percentage}
/>
```

The Circulation progress bar is often used to show download and upload percentages in the application.

- We have passed **props** in CircularProgress Bar component like ,

```
variant?: any;
percentage: number;
```

### Example

```
<CircularProgressBar
variant="warning"
percentage={percentage}
/>
```

### Component Name - Toggle Button Group

Tabs allow you to switch between dirrerent tabs.

- We have passed **Props** like ,

```
Istyle {
bgColor?: string;
color?: string;
borderColor?: string;
}
onToggle?: (e, key) => void;
selectedTab?: string;
disabled?: boolean;
shouldSelectByDefault?: boolean;
children: React.ReactNode;
className?: string;
borderBottom?: boolean;
styleObj?: Istyle;
```

### Example

```
<ToggleBtnGroup
onToggle={clickHandle}
selectedTab={selectedTab}
shouldSelectByDefault={true}
borderBottom={true}
disabled
styleObj=''

> <ToggleBtnGroup.Btn value="tab1">Tab 1</ToggleBtnGroup.Btn>
> <ToggleBtnGroup.Btn value="tab2">Tab 2</ToggleBtnGroup.Btn>
> <ToggleBtnGroup.Btn value="tab3">Tab 3</ToggleBtnGroup.Btn>
> </ToggleBtnGroup>
```

### Component Name - Card Component

Cards are surfaces that display content and actions on a single topic. CardHeader, CardAction , CardContent are children of card Component.

- We have passed **props** in Card Component like

```
type CustomStyle = {
[key: string]: any;
};

children?: ReactNode;
style?: CustomStyle;
raised?: boolean;
variant?: string;
className?: string;
round?: "flat" | "round" | "pill";
```

Card header is a child component of card that should be placed before the card content. It can contain a card title and a card subtitle.

- We have passed **props** in card Header component like,

```
title: ReactNode;
style?: CustomStyle;
subheader?: ReactNode;
titleTypographyProps?: any;
action?: ReactNode;
avatar?: ReactNode;
children?: ReactNode;
className?: string;
divider?: "light" | "dark";
```

The action area of the card can be specified by wrapping its contents in a CardAction component.

-We have passed **props** in CardAction component like,

```
style?: CustomStyle;
children?: ReactNode;
raised?: boolean;
variant?: string;
className?: string;
divider?: "light" | "dark";
```

- We have passed **props** in CardContent component like,

```
children?: ReactNode;
style?: CustomStyle;
raised?: boolean;
variant?: string;
className?: string;
divider?: "light" | "dark";
```

### Example

```
<Card round="round" >
<Card.CardHeader title="" divider="light">
<div>Basic</div>
</Card.CardHeader>
<Card.CardContent
className={}
divider="light"
>
<div className=''>Segoe UI</div>
<div className=''>Font Family</div>
</Card.CardContent>
<Card.CardAction className={}>
</Card.CardAction>
</Card>
```

### Component Name - Modal Component

The modal component provides a solid foundation for creating dialogs, popovers, lightboxes, or whatever else.

- In Modal component We have passed **props** for button like ,

```
IsettingProps {
modalId?: string;
className?: string;
variant?: string;
}
onHidden?: () => void;
children?: React.ReactNode;
setting?: IsettingProps;
showOverlay?: boolean;
```

Modal.Header, Modal.Body, Modal.CloseIcon, Modal.CenterButton,Modal.Footer are childern of modal.

Modal.Header is use for title or subtitle.

- We have passed **props** like,

```
className?: string;
children?: React.ReactNode
```

Modal.Body is use for content.

- We have passed **props** in Modal.Body like,

```
children?: React.ReactNode;
className?: string;
```

Modal.CloseIcon is use for canel the Modal.

- We have passed **props** in Modal.CloseIcon like,

```
  onClick?: () => void;
```

Modal.CenterButton is use for the Button and allow users to take action.

- We have passed **props** in Modal.CenterButton component like

```
btnClick?: (e) => void;
variant?: "primary" | "default" | "success" | "error" | "info" | "warning";
```

- We have passed **props** in Modal.Footer component like,

```
btnProp?: object;
bottomButton?: boolean;
```

### Example

```
<Modal
onHidden=()
showOverlay={true}
setting=''

> <Modal.CloseIcon />
> <Modal.Header className=''>

<div>Modal Header </div>
</Modal.Header>
<Modal.Body>
<div >Modal Body </div>
</Modal.Body>
<Modal.CenterButton variant="error" btnClick={}>
Center Button
</Modal.CenterButton>
</Modal>
```

### Component Name - List Component

Lists are continuous, vertical indexes of text or images.

ListItem , List.Header are children of List COmponent.

- We have passed **props** in List Component like

```
style?: any;
className?: any;
children?: ReactNode;
```

List.Header is used for the stitle or subtitle

- We have passed **props** in List.Header Component like,

```
style?: any;
className?: any;
listHeaderSection?: ReactNode
```

- We have used **props** in ListItem Component like

```
style?: any;
className?: any;
children?: ReactNode;
leftSection?: ReactNode;
midSection?: ReactNode;
rightSection?: ReactNode;
onClick?: React.MouseEventHandler<HTMLLIElement>;
selectable?: boolean;
highlightSelected?: boolean;
selected?: boolean;
```

### Component Name - Error page

Component is design to handle for No records and error pages.

- We have used **props** in Error page Component like

```
errorImage?: string;
title?: string;
titleColor?: string;
subtitle?: string;
subTitleColor?: string;
buttonTitle?: string;
disabled?: boolean;
onClick?: (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
buttonSize?: "xs" | "sm" | "md" | "lg" | "xl" | "xxl";
buttonColor?:
| "primary"
| "default"
| "success"
| "error"
| "info"
| "warning";
buttonRound?: "round" | "pill" | "flat";
buttonVariant?: "contained" | "outline" | "soft" | "text";
className?: string;
imageColor?: string;
style?: CustomStyle;
imageWidth: string;
imageHeight: string;
```

### Example

```
Error404.args = {
buttonSize: "lg",
buttonTitle: "Back To Home",
titleColor: "black",
subTitleColor: "black",
subtitle:
"The page you are looking was moved, removed, renamed, or might never exist!",
className: "",
imageColor: "gray"
};
```

### Component Name - MileStone Card Component

Custom design for Complete Saving project.

MileStoneCard.Title, MileStoneCard.Body, MileStoneList are children of MileStoneCard Component.

- We have passed **props** in MileStoneCard Component.

```
className?: string;
children?: ReactNode;
style?: CustomStyle;
```

- We have passed **props** in MileStoneCard Component.

```
title?: ReactNode | string;
itemNum?: ReactNode | string;
titleClass?: string;
styleItemNum?: CustomStyle;
styleTitle?: CustomStyle;
```

- We have passed props in MileStoneCard.Body Component.

```
children?: ReactNode | string;
bodyClass?: string;
style?: CustomStyle;
```

- We have passed **props** in MileStoneList Component.

```
imgUrl?: string;
title: ReactNode | string;
subTitle?: ReactNode | string;
listClass?: string;
titleStyle?: CustomStyle;
subTitleStyle?: CustomStyle;
customDiv?: ReactNode;
```

### Example

```
<MileStoneCard>
<MileStoneCard.Title
itemNum="1. "
title="Enter your name, address and email."
/>
<MileStoneCard.Body/>
<MileStoneList/>
</MileStoneCard>
```

### Component Name - Input Component

In Input filed component users can enter or edit text.

- In Input component we have passed **props** like

```
label: string;
value: string;
placeHolder: string;
type: any;
children: React.ReactNode;
onChange: (event) => void;
className: string;
onFocus: (e) => void;
onBlur: () => void;
as: any;
ref: any;
onPaste?: (event) => void;
```

### Example :

```
<Input
 as="input"
ref=''
placeHolder="Enter value"
value=''
className=''
type = 'text'
/>
```

### Component Name - InputGroup Component

- In Input Group component we have passed **props** like

```
inputProps?: InputProps;
children?: React.ReactNode;
onFocus?: () => void;
onBlur?: Boolean;
preAppend?: React.ReactNode | string;
append?: React.ReactNode | string;
rightHtml?: React.ReactNode;
passwordShown?: (type: boolean) => void;
disabledInput?: Boolean;
flat?: Boolean;
className?: string;
top?: Boolean;
borderBottom?: Boolean;
inputWithMovingLabel?: Boolean;
helperText?: string;
successMsg?: string | Boolean;
errorMsg?: string | Boolean;
multiLine?: Boolean;
maxRow?: number | undefined;
rows?: number;
autoComp?: Boolean;
options?: object | undefined;
filterOption?: (event) => void;
onSelection?: (event) => void;
isMulti?: Boolean;
selected?: string;
onClose?: (event) => void;
label?: string;
```

### Example

```
<InputGroup
preAppend="+91"
append="+91"
disabledInput={false}
flat={false}
borderBottom = false
successMsg = false
errorMsg = true
/>
```

### Component Name - InputWithMovingLabel Component

In InputWithMovingLabel component we have used for the position for the label

In InputWithMovingLabel component we have used InputGroup Component props.

**inputWithMovingLabel** props are used to create a InputWithMovingLabel component.

### Example

```
<InputWithMovingLabel
helperText="Enter message here"
successMsg={true}
top={false}
multiLine={true}
inputWithMovingLabel = true
/>
```

### Component Name - Text Area Component

In Text area component we have used for multi line purpose (auto size) , for text area we have passed **multiLine** .

If we can pass **maxRow** props in the text area component it will display Maximum number of rows when multiline option is set to true.

### Example

```
<InputWithMovingLabel
helperText="Enter message here"
successMsg={true}
top={false}
multiLine={true}
maxRow={2}
/>
```
